# Judges Edition - iOS source scaffold

Status: SOURCE SCAFFOLD (not compiled in this Linux workspace; no Apple
toolchain available here). It compiles on macOS with Xcode 15+ / Swift 5.9.

## Provenance and boundary

This scaffold implements the private judging workflows defined for the
Judges Edition. Per the project's strict boundary rules, it must be
integrated into the authorized BOTB application project by whoever holds
the source rights to that project. Do NOT present this scaffold as a
modified original BOTB application; the build script in
`build/build_judges_edition.sh` supports exactly two honest routes:
building this scaffold as-is (labelled clearly), or integrating these
workflows into the authorized source project.

## Files

| File | Role |
| --- | --- |
| `BOTBJudgesApp.swift` | Entry point; AuthGate wraps all tabs |
| `AuthGate.swift` | First-launch PIN setup/unlock, PBKDF2 + Keychain, lockout |
| `CoordinateEngine.swift` | Swift port of `engine/coordinate_engine.py` |
| `AssessmentModels.swift` | Codable records mirroring `schemas/assessment.schema.json` |
| `RecordsStore.swift` | Atomic record persistence + verification, hash-chained audit |
| `JudgeSubmissionView.swift` | Image picking, SHA-256 image identity, crosshair placement/save |
| `CrosshairOverlay.swift` | Drag/adjust crosshair; consensus + other judges markers |
| `MultiJudgeCompareView.swift` | Comparison, consensus, approval gate, audit history |
| `AIProposalView.swift` | AI proposal intake, strictly separate from judge submissions |

## Build (macOS)

```bash
brew install xcodegen
xcodegen generate          # produces BOTBJudgesEdition.xcodeproj
open BOTBJudgesEdition.xcodeproj
# or:
xcodebuild -project BOTBJudgesEdition.xcodeproj -scheme BOTBJudgesEdition \
    -destination 'generic/platform=iOS' -configuration Release build
```

Signing is intentionally left to the project owner (see
`SIGNING_INSTRUCTIONS.md` at the delivery root). The XcodeGen spec ships
with `CODE_SIGNING_ALLOWED: NO` so an unsigned build succeeds before the
owner applies their own identity.

## Cross-language notes

- The Swift engine mirrors the Python reference rule-for-rule (same
  round-half-even, same Weiszfeld parameters). Coordinates and distances
  agree exactly; canonical-JSON hashing uses JSONEncoder with
  `.sortedKeys` + `.withoutEscapingSlashes`. When exchanging hashed records
  between the Python reference tools and the app, run the integration test
  in `verification/` to confirm digest compatibility on your exact toolchain
  versions before relying on cross-platform hash equality.
- Record JSON field names match the Python reference exactly
  (snake_case), so records are interchangeable.
