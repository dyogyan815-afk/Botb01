# BOTB Private Judges Edition — ریپۆی دروستکردنی IPA

ئەم ریپۆیە پاکێجی تەواو و سەربەخۆیە (self-contained) بۆ دروستکردنی IPA ی
Judges Edition لەسەر **GitHub Actions** بە پێکەنەری macOS ی بەخۆڕایی —
**بێ پێویستی بە ماک و بێ Xcode لەلای تۆ**.

- تۆماری تەواوی گفتوگۆی پڕۆژە: [`CHAT_HISTORY.md`](CHAT_HISTORY.md)
- سپێسیفیکەیشنی تەواوی پڕۆژە: [`PROJECT_CONTEXT.md`](PROJECT_CONTEXT.md)
- وردبینی وۆرکسپەیس و IPA: [`WORKSPACE_AUDIT.md`](WORKSPACE_AUDIT.md) و [`verification/IPA_AUDIT_REPORT.md`](verification/IPA_AUDIT_REPORT.md)

## پێکهاتەی ریپۆ

| ڕێڕەو | وەسف |
| --- | --- |
| `.github/workflows/build.yml` | وۆرکفڵۆی Actions — سەرەتا تاقیکردنەوەکانی پایتۆن جێبەجێ دەکات، پاشان IPA ی نەئیمزا دروست دەکات |
| `ios/JudgesEdition/` | سۆرسی SwiftUI ی ئەپەکە: ٩ فایلی Swift + `project.yml` (XcodeGen) |
| `engine/` | بزوێنەری پایتۆن: coordinate engine، crosshair records، multi-judge consensus، auth |
| `tests/` | ٥٠ تاقیکردنەوەی unittest — هەموو Pass بوون |
| `schemas/` | سکیمای JSON ی تۆمارەکان |
| `docs/` | سپێسیفیکەیشنی بزوێنەر + پێرسۆنای پڕۆژە |
| `build/` | سکریپتی دروستکردن لەسەر ماک + ڕێنمایی ویندۆز (Sideloadly/AltStore) |
| `verification/` | بەڵگەکان: لۆگی تاقیکردنەوەکان (٥٠/٥٠)، لۆگی e2e، وردبینی IPA |

## خێرا: لە IPA بگە — ٥ هەنگاو

1. لە **github.com/new** ریپۆیەکی نوێ دروست بکە → ناو بنووسە → **Public** → **Create repository**
2. **Add file → Upload files** → هەموو ناوەڕۆکی ئەم فۆڵدەرە بارکە (فۆڵدەری `.github` یش لەگەڵدا بێت) → **Commit changes**
   - **تێبینی ویندۆز:** فۆڵدەری `.github` شاراوەیە. لە Explorer لای **View → Show → Hidden items** چالاک بکە تا دیار بێت.
   - ئەگەر هەر نەکرا: لە GitHub **Add file → Create new file** بکە، ناوی `.github/workflows/build.yml` بنووسە، و ناوەڕۆکی فایلەکە پەیست بکە.
3. تابی **Actions** → کلیک لە "I understand my workflows, go ahead and enable them"
4. لای چەپ: **Build Judges Edition IPA (unsigned)** → **Run workflow** → ٣–٥ خەرەتە چاوەڕێ بکە
5. کلیک لەسەر run ە تەواوبووەکە → بەشی **Artifacts** → **BOTB_Judges_Edition_unsigned_ipa** داگرە

## ئیمزا و دامەزراندن

IPA ی Artifact ەکە **نەئیمزایە**. بۆ ئیمزا لەسەر ویندۆزی خۆت:
[`build/WINDOWS_SIDELOAD_GUIDE.md`](build/WINDOWS_SIDELOAD_GUIDE.md) — بە
Sideloadly یان AltStore بە Apple ID ی خۆت (هەژماری خۆڕایی = ٧ ڕۆژ، پاشان دووبارە ئیمزا).

## دۆخی ڕاستگۆیی — پێویستە بخوێنیتەوە

- ئەمە نەرمەکاڵایەکی **سەربەخۆیە** بە ناوی Judges Edition (کۆدی نوێی SwiftUI).
  **دەستکاری ئەپی ڕەسەنی BOTB نییە** و نابێت وەک ئەوی دەربخرێت — ئەمە یاسای پڕۆژەکەیە.
- IPA ی ڕەسەنی BOTB (`com.botb.winacar`، وەشان 3.1.96) لە Google Drive وەرگیرا و
  پشکنین کرا — **سۆرسی تێدا نییە و ناتوانرێت بکرێتە Judges Edition**؛ وەک ڕاپەرت
  پاشەکەوت کراوە: `verification/IPA_INSPECTION_REPORT.md`.
- ئەم چاتە لینوکسە و توانای کۆمپایڵی iOS ی نییە — بۆیە دروستکردن لە GitHub ئەنجام
  دەدرێت و ئیمزا لەلایەن خاوەن پڕۆژەوە دەکرێت.
- هەموو ئەنجامەکانی تاقیکردنەوە بەڵگەی ڕاستەقینەن:
  `verification/unittest_output.txt` (٥٠/٥٠) و `verification/e2e_output.txt`.
- هەرگیز پاسیڤۆردی RDP یان Apple ID مەنێرە بۆ هیچ کەسێک — پێویست نییە و مەترسی ئاسایشە.

## ئەگەر دروستکردن شکا

Artifact ی **build_log** داگرە و بنێرە بۆ چاتەکە. هۆکارە باوەکان لە
[`build/GITHUB_BUILD_GUIDE.md`](build/GITHUB_BUILD_GUIDE.md) نووسراون.
